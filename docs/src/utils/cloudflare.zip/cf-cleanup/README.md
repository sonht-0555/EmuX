# delete-all-deployments

Deletes all deployments given a Pages project name

## How to

cd /Users/hoang.tuan.son/Documents/GitHub/Emux/.cf-cleanup && \
CF_AUTH_EMAIL=hoangtuanson91@gmail.com CF_GLOBAL_API_KEY=cfk_PUz08Gq1120BsxGZ6nPxUgJXuyE87jfVO3AKBbcW9e0f929f CF_ACCOUNT_ID=eb87ba420dc05b1a16d8f40972e59407 CF_PAGES_PROJECT_NAME=kabu npm start
